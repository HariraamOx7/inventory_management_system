const sequelize = require('../config/db');
const preventReferencedDeletion = require('../services/preventReferencedDeletion');
const errorStatus = require('../services/errorStatus');
const { Op } = require('sequelize');
const Supplier = require('../models/Supplier');


const nextSupplierCode = async () => {
  const [rows] = await sequelize.query("SELECT COALESCE(MAX(CAST(PartyCode AS UNSIGNED)), 0) AS maximum FROM suppliers WHERE PartyCode REGEXP '^[0-9]+$'");
  return (BigInt(String(rows[0].maximum)) + 1n).toString();
};

exports.getSuppliers = async (req, res) => {
  try {
    const { search, department, place, gstStatus, page, limit } = req.query;
    
    const andConditions = [];

    if (search && search.trim() !== '') {
      andConditions.push({
        [Op.or]: [
          { AccountName: { [Op.like]: `%${search.trim()}%` } },
          { PartyCode: { [Op.like]: `%${search.trim()}%` } }
        ]
      });
    }

    if (department && department !== 'ALL') {
      andConditions.push({ Department: department });
    }

    if (place && place !== 'ALL') {
      andConditions.push({ Place: place });
    }

    if (gstStatus === 'registered') {
      andConditions.push({
        GSTNo: {
          [Op.and]: [
            { [Op.ne]: null },
            { [Op.ne]: '' }
          ]
        }
      });
    } else if (gstStatus === 'unregistered') {
      andConditions.push({
        [Op.or]: [
          { GSTNo: null },
          { GSTNo: '' }
        ]
      });
    }

    const queryOptions = {
      order: [['PartyCode', 'ASC']]
    };

    if (andConditions.length > 0) {
      queryOptions.where = { [Op.and]: andConditions };
    }

    if (page || limit) {
      const pageNum = Math.max(1, parseInt(page) || 1);
      const limitNum = Math.max(1, parseInt(limit) || 10);
      queryOptions.limit = limitNum;
      queryOptions.offset = (pageNum - 1) * limitNum;
    }

    const { count, rows } = await Supplier.findAndCountAll(queryOptions);
    const pageNum = Math.max(1, parseInt(page) || 1);
    const limitNum = parseInt(limit) || count || 10;

    res.json({
      success: true,
      data: rows,
      pagination: {
        total: count,
        page: pageNum,
        totalPages: Math.ceil(count / limitNum) || 1,
        limit: limitNum
      }
    });
  } catch (error) {
    console.error('Error fetching suppliers:', error);
    res.status(errorStatus(error)).json({
      success: false, 
      message: 'Error fetching suppliers',
      error: error.message 
    });
  }
};

exports.getLastCode = async (req, res) => {
  try {
    const lastCode = (BigInt(await nextSupplierCode()) - 1n).toString();
    res.json({
      success: true,
      data: { lastCode: lastCode }
    });
  } catch (error) {
    console.error('Error fetching last code:', error);
    res.status(errorStatus(error)).json({
      success: false,
      message: 'Error fetching last code',
      error: error.message
    });
  }
};

exports.addSupplier = async (req, res) => {
  try {
    const {
      PartyCode, AccCode,
      Description, AccountName, Place, Address, DeliveryAddress,
      OpeningCredit, OpeningDebit, TINNo, CSTNo, PhNo, Fax, CellNo, Email,
      WebSite, AccountNo, ContactPerson, Pincode, PanNumber, Department, GSTNo
    } = req.body;
    
    const requestedCode = PartyCode || AccCode;
    if (!AccountName) {
      return res.status(400).json({
        success: false,
        message: 'Account Name is required'
      });
    }
    
    let newSupplier;
    for (let attempt = 0; attempt < 5; attempt++) {
      const code = requestedCode || await nextSupplierCode();
      try {
      newSupplier = await Supplier.create({
      PartyCode: String(code).trim(),
      Description: Description ? Description.trim() : null,
      AccountName: AccountName ? AccountName.trim() : null,
      Place: Place ? Place.trim() : null,
      Address: Address ? Address.trim() : null,
      DeliveryAddress: DeliveryAddress ? DeliveryAddress.trim() : null,
      OpeningCredit: OpeningCredit || 0,
      OpeningDebit: OpeningDebit || 0,
      TINNo: TINNo ? TINNo.trim() : null,
      CSTNo: CSTNo ? CSTNo.trim() : null,
      PhNo: PhNo ? PhNo.trim() : null,
      Fax: Fax ? Fax.trim() : null,
      CellNo: CellNo ? CellNo.trim() : null,
      Email: Email ? Email.trim() : null,
      WebSite: WebSite ? WebSite.trim() : null,
      AccountNo: AccountNo ? AccountNo.trim() : null,
      ContactPerson: ContactPerson ? ContactPerson.trim() : null,
      Pincode: Pincode ? Pincode.trim() : null,
      PanNumber: PanNumber ? PanNumber.trim() : null,
      Department: Department ? Department.trim() : null,
      GSTNo: GSTNo ? GSTNo.trim() : null
      });
      break;
      } catch (error) {
        if (requestedCode || error.name !== 'SequelizeUniqueConstraintError' || attempt === 4) throw error;
      }
    }
    
    res.status(201).json({
      success: true,
      data: newSupplier
    });
  } catch (error) {
    console.error('Error adding supplier:', error);
    res.status(errorStatus(error)).json({
      success: false, 
      message: 'Error adding supplier',
      error: error.message 
    });
  }
};

exports.updateSupplier = async (req, res) => {
  try {
    const partyCode = req.query?.code ?? req.params.partyCode ?? req.params.accCode;
        if (typeof partyCode !== 'string' || !partyCode.trim()) return res.status(400).json({ success: false, message: 'A valid record code is required' });
    const {
      Description, AccountName, Place, Address, DeliveryAddress,
      OpeningCredit, OpeningDebit, TINNo, CSTNo, PhNo, Fax, CellNo, Email,
      WebSite, AccountNo, ContactPerson, Pincode, PanNumber, Department, GSTNo
    } = req.body;

    const supplier = await Supplier.findByPk(partyCode);
    if (!supplier) {
      return res.status(404).json({
        success: false,
        message: 'Supplier not found'
      });
    }

    await supplier.update({
      Description: Description ? Description.trim() : null,
      AccountName: AccountName ? AccountName.trim() : null,
      Place: Place ? Place.trim() : null,
      Address: Address ? Address.trim() : null,
      DeliveryAddress: DeliveryAddress ? DeliveryAddress.trim() : null,
      OpeningCredit: OpeningCredit || 0,
      OpeningDebit: OpeningDebit || 0,
      TINNo: TINNo ? TINNo.trim() : null,
      CSTNo: CSTNo ? CSTNo.trim() : null,
      PhNo: PhNo ? PhNo.trim() : null,
      Fax: Fax ? Fax.trim() : null,
      CellNo: CellNo ? CellNo.trim() : null,
      Email: Email ? Email.trim() : null,
      WebSite: WebSite ? WebSite.trim() : null,
      AccountNo: AccountNo ? AccountNo.trim() : null,
      ContactPerson: ContactPerson ? ContactPerson.trim() : null,
      Pincode: Pincode ? Pincode.trim() : null,
      PanNumber: PanNumber ? PanNumber.trim() : null,
      Department: Department ? Department.trim() : null,
      GSTNo: GSTNo ? GSTNo.trim() : null
    });

    res.json({
      success: true,
      data: supplier
    });
  } catch (error) {
    console.error('Error updating supplier:', error);
    res.status(errorStatus(error)).json({
      success: false,
      message: 'Error updating supplier',
      error: error.message
    });
  }
};

exports.deleteSupplier = async (req, res) => {
  try {
    const partyCode = req.query?.code ?? req.params.partyCode ?? req.params.accCode;
        if (typeof partyCode !== 'string' || !partyCode.trim()) return res.status(400).json({ success: false, message: 'A valid record code is required' });

    const supplier = await Supplier.findByPk(partyCode);
    if (!supplier) {
      return res.status(404).json({
        success: false,
        message: 'Supplier not found'
      });
    }

        await preventReferencedDeletion('Supplier', supplier);

    await supplier.destroy();
    res.json({
      success: true,
      message: 'Supplier deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting supplier:', error);
    res.status(errorStatus(error)).json({
      success: false,
      message: 'Error deleting supplier',
      error: error.message
    });
  }
};
